package com.example.g1roadtest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class main_page extends Activity {

    Button btn_back,btn_quiz, btn_reports;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);


        btn_back = (Button) findViewById(R.id.btnBack);
        btn_quiz = (Button) findViewById(R.id.btnQuiz);
        btn_reports = (Button) findViewById(R.id.btnResources);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                   Intent myIntent = new Intent(getBaseContext(), login.class);
                                 startActivity(myIntent);

            }

        });
        btn_quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent myIntent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(myIntent);

            }

        });
        btn_reports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri= Uri.parse("http://www.mto.gov.on.ca/english/publications/mto-research-library-online-catalogue.shtml");
                Intent myIntent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(myIntent);


                /*
                Intent myIntent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(myIntent);

                 */

            }

        });

    }
}
