package com.example.g1roadtest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.preference.PreferenceManager;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Collections;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    public static final String CHOICES = "pref_numberOfChoices";
    public static final String REGIONS = "pref_regionsToInclude";
    private Object SharedPreferences;
    private boolean phoneDevice=true;
    private boolean preferencesChanged=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);

        PreferenceManager.setDefaultValues(this,R.xml.preferences,false);

        PreferenceManager.getDefaultSharedPreferences(this).
                registerOnSharedPreferenceChangeListener(
                        preferenceChangeListener);
//            ImageView mapImageView = (ImageView) this.findViewById(R.id.mapImageView);
//            AssetManager assetManager = this.getAssets();
//            try{
//                InputStream stream = assetManager.open("united_states_map.jpg");
//                Drawable map = Drawable.createFromStream(stream, null);
//                if(mapImageView != null)
//            mapImageView.setImageDrawable(map);
//        } catch (IOException exception) {
//            Log.e("Quiz Activity", "Error loading map image", exception);
//        }
    }

    private SharedPreferences.OnSharedPreferenceChangeListener preferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

            preferencesChanged = true;

            FirstFragment quizFragment = (FirstFragment) getSupportFragmentManager().findFragmentById(R.id.quizFragment);

            if(quizFragment != null && key.equals(CHOICES)){
                quizFragment.updateGuessRows(sharedPreferences);
                quizFragment.resetQuiz();;

            }else if(quizFragment != null && key.equals(REGIONS)){
                Set<String> regions = sharedPreferences.getStringSet(REGIONS,null);
                if(regions != null &&  regions.size() > 0){
                    quizFragment.updateRegion(sharedPreferences);

                    if(regions.size() == 1 &&  regions.contains("Common")) {
                        quizFragment.SIGNS_IN_QUIZ = 6;

                    }else if(regions.size() == 1 &&  regions.contains("Information")) {
                        quizFragment.SIGNS_IN_QUIZ = 13;

                    }else if(regions.size() == 1 &&  regions.contains("Temporary")) {
                        quizFragment.SIGNS_IN_QUIZ = 14;

                    }else if(regions.size() == 2 &&  regions.contains("Common") && regions.contains("Information")) {
                        quizFragment.SIGNS_IN_QUIZ = 19;

                    } else{
                        quizFragment.SIGNS_IN_QUIZ = 20;

                    }
                    quizFragment.resetQuiz();

                }else {
                    quizFragment.SIGNS_IN_QUIZ = 6;

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    regions.add(getString(R.string.default_region));
                    editor.putStringSet(REGIONS, regions);
                    editor.apply();

                    Toast.makeText(MainActivity.this,R.string.default_type_message,Toast.LENGTH_SHORT).show();
                }


            }

        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        if (preferencesChanged) {
            FirstFragment quizFragment = (FirstFragment) getSupportFragmentManager().findFragmentById(R.id.quizFragment);
            quizFragment.updateGuessRows(PreferenceManager.getDefaultSharedPreferences(this));
            quizFragment.updateRegion(PreferenceManager.getDefaultSharedPreferences(this));
            preferencesChanged = false;
            quizFragment.resetQuiz();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this,SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}