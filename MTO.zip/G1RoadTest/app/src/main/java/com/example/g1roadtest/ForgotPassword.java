package com.example.g1roadtest;
        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.util.Log;
        import android.util.Patterns;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;
        import java.io.BufferedReader;
        import java.io.InputStreamReader;
        import java.net.HttpURLConnection;
        import java.net.URL;
        import com.basgeekball.awesomevalidation.AwesomeValidation;
        import com.basgeekball.awesomevalidation.ValidationStyle;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;

public class ForgotPassword extends Activity {

    EditText edit_email;
    EditText edit_pass;
    EditText edit_mobile;
    Button btn_forgot;
    String c;
    String b;
    String s;
    private AwesomeValidation awesomeValidation;
    private static final String REGISTER_URL="https://mtoroadquiz123.000webhostapp.com/forgotpass.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_password);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        edit_email = (EditText) findViewById(R.id.editEmail1);
        edit_pass = (EditText) findViewById(R.id.newPassword);
        edit_mobile = (EditText) findViewById(R.id.confirmPassword);
        btn_forgot = (Button) findViewById(R.id.buttonNext);
        awesomeValidation.addValidation(this, R.id.editEmail1, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        awesomeValidation.addValidation(this, R.id.newPassword,"^((?=.*\\d)(?=.*[@#$%]).{6,20})$", R.string.passerror);
        awesomeValidation.addValidation(this, R.id.confirmPassword,"^((?=.*\\d)(?=.*[@#$%]).{6,20})$", R.string.passerror);

        btn_forgot .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (awesomeValidation.validate()) {
                    registerUser();
                    // Toast.makeText(this, "Validation Successfull", Toast.LENGTH_LONG).show();
                    //process the data further
                }
                //process the data further
            }

        });

    }
    private void registerUser() {

        String email = edit_email.getText().toString().trim().toLowerCase();
        String password = edit_pass.getText().toString().trim().toLowerCase();
        String mobile= edit_mobile.getText().toString().trim().toLowerCase();
        if(password.equals(mobile)) {
            register(email, password);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Passsword does not match", Toast.LENGTH_SHORT).show();
        }
    }

    private void register(String email, String password)
    {
        email=email.replace(" ","%20");
        String urlSuffix = "?email=" + email + "&password=" + password;
        class RegisterUser extends AsyncTask<String, Void, String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ForgotPassword.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(myIntent);


            }

            @Override
            protected String doInBackground(String... params) {
                String s = params[0];
                BufferedReader bufferReader=null;
                try {
                    URL url=new URL(REGISTER_URL+s);
                    Log.d("baba",REGISTER_URL+s);
                    HttpURLConnection con=(HttpURLConnection)url.openConnection();
                    bufferReader=new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String result;
                    result=bufferReader.readLine();
                    return  result;

                }catch (Exception e){
                    return null;
                }
            }

        }
        RegisterUser ur=new RegisterUser();
        ur.execute(urlSuffix);
    }

}


