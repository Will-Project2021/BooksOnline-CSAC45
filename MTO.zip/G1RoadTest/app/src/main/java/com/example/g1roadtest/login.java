package com.example.g1roadtest;
        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.util.Log;
        import com.basgeekball.awesomevalidation.AwesomeValidation;
        import com.basgeekball.awesomevalidation.ValidationStyle;

        import android.util.Patterns;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;
        import java.io.BufferedReader;
        import java.io.InputStreamReader;
        import java.net.HttpURLConnection;
        import java.net.URL;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.annotation.NonNull;
        import androidx.appcompat.widget.Toolbar;

        import com.android.volley.DefaultRetryPolicy;
        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.StringRequest;
        import com.android.volley.toolbox.Volley;
        import com.google.android.gms.common.api.ApiException;
        import com.google.android.gms.common.api.CommonStatusCodes;
        import com.google.android.gms.safetynet.SafetyNet;
        import com.google.android.gms.safetynet.SafetyNetApi;
        import com.google.android.gms.tasks.OnFailureListener;
        import com.google.android.gms.tasks.OnSuccessListener;

        import org.json.JSONObject;

        import java.util.HashMap;
        import java.util.Map;

public class login extends AppCompatActivity implements View.OnClickListener {
    EditText edit_username;
    EditText edit_email;
    EditText edit_pass;
    EditText edit_mobile;
    EditText edit_address;
    EditText edit_age;
    Button btn_sign,btn_forgot;
    String c;
    String b;
    String s;
    Button btnVerify;
    TextView tvVerify;
    String TAG = login.class.getSimpleName();
    String SITE_KEY = "6LeTw3kaAAAAAMc7MpLbPAjrPk_uL-XtJUAHmF3z";
    String SITE_SECRET_KEY = "6LeTw3kaAAAAABzYG0_8gjUgwegxKu4WdvIdmJPB";
    RequestQueue queue;
    private AwesomeValidation awesomeValidation;
    private static final String REGISTER_URL="https://mtoroadquiz123.000webhostapp.com/login.php";
    int number=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        edit_username = (EditText) findViewById(R.id.editName);
        edit_email = (EditText) findViewById(R.id.editEmail);
        edit_pass = (EditText) findViewById(R.id.editPass);
        edit_mobile = (EditText) findViewById(R.id.editMob);
        edit_address = (EditText) findViewById(R.id.editAddress);
        edit_age = (EditText) findViewById(R.id.editAge);
        btn_sign = (Button) findViewById(R.id.buttonAcount);
        btn_forgot = (Button) findViewById(R.id.buttonForgot);
        btnVerify = findViewById(R.id.btn_verify);
        tvVerify = findViewById(R.id.tv_verify);
        btnVerify.setOnClickListener(this);
        queue = Volley.newRequestQueue(getApplicationContext());
        awesomeValidation.addValidation(this, R.id.editName, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.editAddress, "^[A-Za-z0-9\\s]{2,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.addresserror);
        awesomeValidation.addValidation(this, R.id.editEmail, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        awesomeValidation.addValidation(this, R.id.editMob, "^[2-9]{2}[0-9]{8}$", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.editAge, "^[0-9]{2}$", R.string.ageerror);
        awesomeValidation.addValidation(this, R.id.editPass,"^((?=.*\\d)(?=.*[@#$%]).{6,20})$", R.string.passerror);
        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (awesomeValidation.validate() && number==1) {
                    registerUser();
                   // Toast.makeText(this, "Validation Successfull", Toast.LENGTH_LONG).show();
                    //process the data further
                }
                else{
                    Toast.makeText(getApplicationContext(),"Please complete captcha and form details", Toast.LENGTH_LONG).show();
                    //Intent myIntent = new Intent(getBaseContext(), login.class);
                    //startActivity(myIntent);
                }
                    //process the data further
                }

        });

    }
    @Override
    public void onClick(View view) {
        SafetyNet.getClient(this).verifyWithRecaptcha(SITE_KEY)
                .addOnSuccessListener(this, new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>() {
                    @Override
                    public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                        if (!response.getTokenResult().isEmpty()) {
                            handleCaptchaResult(response.getTokenResult());
                        }
                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        if (e instanceof ApiException) {
                            ApiException apiException = (ApiException) e;
                            Log.d(TAG, "Error message: " +
                                    CommonStatusCodes.getStatusCodeString(apiException.getStatusCode()));
                            number=0;
                        } else {
                            Log.d(TAG, "Unknown type of error: " + e.getMessage());
                            number=0;
                        }
                    }
                });
    }

    void handleCaptchaResult(final String responseToken) {
        String url = "https://www.google.com/recaptcha/api/siteverify";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if(jsonObject.getBoolean("success")){
                                tvVerify.setText("You're not a Robot");
                                number=1;
                            }
                        } catch (Exception ex) {
                            Log.d(TAG, "Error message: " + ex.getMessage());
                            number=0;

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error message: " + error.getMessage());
                        number=0;
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("secret", SITE_SECRET_KEY);
                params.put("response", responseToken);
                return params;
            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }
    private void registerUser() {
        String name = edit_username.getText().toString().trim().toLowerCase();
        String email = edit_email.getText().toString().trim().toLowerCase();
        String password = edit_pass.getText().toString().trim().toLowerCase();
        String mobile= edit_mobile.getText().toString();
        String address= edit_address.getText().toString();
        String age= edit_age.getText().toString();
        register(name , email, password, mobile ,address, age );
    }

    private void register(String name,String email, String password,  String mobile, String address, String age)
    {
        name=name.replace(" ","%20");
        String urlSuffix = "?name=" + name +"&email=" +email + "&password=" + password +  "&mobile=" + mobile +"&address=" + address  + "&age=" +age;
        class RegisterUser extends AsyncTask<String, Void, String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
               super.onPreExecute();
               loading = ProgressDialog.show(login.this, "Please Wait", null, true, true);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(getBaseContext(), main_page.class);
                startActivity(myIntent);
            }
            @Override
            protected String doInBackground(String... params) {
                String s = params[0];
                BufferedReader bufferReader=null;
                try {
                    URL url=new URL(REGISTER_URL+s);
                    Log.d("baba",REGISTER_URL+s);
                    HttpURLConnection con=(HttpURLConnection)url.openConnection();
                    bufferReader=new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String result;
                    result=bufferReader.readLine();
                    return  result;

                }catch (Exception e){
                    return null;
                }
            }
        }
        RegisterUser ur=new RegisterUser();
        ur.execute(urlSuffix);
    }
    public void onButtonClick(View v){
        Intent myIntent = new Intent(getBaseContext(), ForgotPassword.class);
        startActivity(myIntent);
    }
}