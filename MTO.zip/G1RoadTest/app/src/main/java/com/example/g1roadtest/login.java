package com.example.g1roadtest;
        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;
        import java.io.BufferedReader;
        import java.io.InputStreamReader;
        import java.net.HttpURLConnection;
        import java.net.URL;

public class login extends Activity {
    EditText edit_username;
    EditText edit_email;
    EditText edit_pass;
    EditText edit_mobile;
    EditText edit_address;
    EditText edit_age;
    Button btn_sign,btn_forgot;
    String c;
    String b;
    String s;
    private static final String REGISTER_URL="https://mtoroadquiz123.000webhostapp.com/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        edit_username = (EditText) findViewById(R.id.editName);
        edit_email = (EditText) findViewById(R.id.editEmail);
        edit_pass = (EditText) findViewById(R.id.editPass);
        edit_mobile = (EditText) findViewById(R.id.editMob);
        edit_address = (EditText) findViewById(R.id.editAddress);
        edit_age = (EditText) findViewById(R.id.editAge);
        btn_sign = (Button) findViewById(R.id.buttonAcount);
        btn_forgot = (Button) findViewById(R.id.buttonForgot);
        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                   registerUser();
                    //process the data further
                }

        });

    }
    private void registerUser() {
        String name = edit_username.getText().toString().trim().toLowerCase();
        String email = edit_email.getText().toString().trim().toLowerCase();
        String password = edit_pass.getText().toString().trim().toLowerCase();
        String mobile= edit_mobile.getText().toString();
        String address= edit_address.getText().toString();
        String age= edit_age.getText().toString();
        register(name , email, password, mobile ,address, age );
    }

    private void register(String name,String email, String password,  String mobile, String address, String age)
    {
        name=name.replace(" ","%20");
        String urlSuffix = "?name=" + name +"&email=" +email + "&password=" + password +  "&mobile=" + mobile +"&address=" + address  + "&age=" +age;
        class RegisterUser extends AsyncTask<String, Void, String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
               super.onPreExecute();
               loading = ProgressDialog.show(login.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(myIntent);


            }

            @Override
            protected String doInBackground(String... params) {
                String s = params[0];
                BufferedReader bufferReader=null;
                try {
                    URL url=new URL(REGISTER_URL+s);
                    Log.d("baba",REGISTER_URL+s);
                    HttpURLConnection con=(HttpURLConnection)url.openConnection();
                    bufferReader=new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String result;
                    result=bufferReader.readLine();
                    return  result;

                }catch (Exception e){
                    return null;
                }
            }

        }
        RegisterUser ur=new RegisterUser();
        ur.execute(urlSuffix);
    }
    public void onButtonClick(View v){
        Intent myIntent = new Intent(getBaseContext(), ForgotPassword.class);
        startActivity(myIntent);
    }
}

