package com.example.ministryoftransportation;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SearchView;
import android.widget.Switch;

import com.example.ministryoftransportation.ADAPTER.RecyclerViewAdapter;
import com.example.ministryoftransportation.DAO.DAO;
import com.example.ministryoftransportation.OBJECTS.Product;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Context context;

    RecyclerView recyclerView;
    RecyclerView.Adapter recyclerViewAdapter;
    RecyclerView.LayoutManager recyclerViewLayoutManager;
    RecyclerViewAdapter accessRecyclerViewAdapter;

    List<Product> products = new ArrayList<>();

    List<String> descriptions = new ArrayList<String>();
    List<String> prices = new ArrayList<String>();
    List<Integer> id = new ArrayList<Integer>();
    List<String> category = new ArrayList<String>();
    List<String> images = new ArrayList<String>();

    String[] data_descriptions = new String[] {};
    String[] data_prices = new String[] {};
    Integer[] data_id = new Integer[] {};
    String[] data_category = new String[] {};
    String[] data_images = new String[] {};

    Button insert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();

        insert = findViewById(R.id.botaoExcluir);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder confirmaExclusao = new AlertDialog.Builder(MainActivity.this);
                confirmaExclusao.setTitle("Alert !");
                confirmaExclusao.setMessage("Are you sure you want to delete the selected products ?");
                confirmaExclusao.setCancelable(false);
                confirmaExclusao.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        for(int i = 0; i < accessRecyclerViewAdapter.productsToRemove.size(); i++){
                            removeProduct(accessRecyclerViewAdapter.productsToRemove.get(i));
                        }
                        findOnDatabase();

                    }
                });
                confirmaExclusao.setNegativeButton("No", null);
                confirmaExclusao.create().show();
            }
        });



        recyclerView = findViewById(R.id.recyclerView);
        findOnDatabase();

    }




    private void findOnDatabase() {

        DAO dao2 = new DAO(getApplicationContext());

        products = dao2.findProduct("n");

        id = new ArrayList<>();
        descriptions = new ArrayList<>();
        prices = new ArrayList<>();
        category = new ArrayList<>();
        images = new ArrayList<>();

        data_descriptions = new String[] {};
        data_id = new Integer[] {};
        data_prices = new String[] {};
        data_category = new String[] {};
        data_images = new String[] {};

        for(Product productFound : products){
            id.add(productFound.getId());
            descriptions.add(productFound.getDescription());
            prices.add(String.valueOf(productFound.getPrice()));
            category.add(productFound.getCategory());
            images.add(String.valueOf(productFound.getImage()));
        }

        data_descriptions = descriptions.toArray(new String[0]);
        data_id = id.toArray(new Integer[0]);
        data_prices = prices.toArray(new String[0]);
        data_category = category.toArray(new String[0]);
        data_images = images.toArray(new String[0]);

        recyclerViewLayoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(recyclerViewLayoutManager);

        preencheRecycler();

    }

    private void preencheRecycler() {

        accessRecyclerViewAdapter.productsToRemove = new ArrayList<>();
        Log.d("images4 ", " 4 " + images);
        recyclerViewAdapter = new RecyclerViewAdapter(context,
                data_id,
                data_descriptions,
                data_prices,
                data_category,
                data_images);
        recyclerView.setAdapter(recyclerViewAdapter);



    }

    private void removeProduct(Integer productId) {
        DAO dao = new DAO(getApplicationContext());
        dao.removeProduct(productId);
        dao.close();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);

        MenuItem addProduct = menu.findItem(R.id.menu_add_product);
        addProduct.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Intent intent = new Intent(context, AddProduct.class);
                intent.putExtra("editing","n");
                startActivity(intent);

                return false;
            }
        });



        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public void onResume(){
        super.onResume();
        findOnDatabase();
    }
}