package com.example.ministryoftransportation.ADAPTER;


import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.widget.CompoundButtonCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ministryoftransportation.AddProduct;
import com.example.ministryoftransportation.R;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    Context context;
    List<String> productsDescription = new ArrayList<String>();
    public static List<Integer> productsToRemove = new ArrayList<Integer>();

    Integer[] id;
    String[] category;
    String[] prices;
    String[] images;

    View viewOnCreate;
    ViewHolder viewHolderLocal;

    public RecyclerViewAdapter(Context contextReceived,
                               Integer[] idReceived,
                               String[] descriptionsReceived,
                               String[] pricesReceived,
                               String[] categoryReceived,
                               String[] imagesReceived) {
        context = contextReceived;
        productsDescription.addAll(Arrays.asList(descriptionsReceived));
        id = idReceived;
        prices = pricesReceived;
        category = categoryReceived;
        images = imagesReceived;


    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public TextView textDescription;
        public TextView textPrice;
        public TextView textCategory;
        public ImageView icon;
        public CheckBox checkBox;

        public ViewHolder(View itemView) {
            super(itemView);
            textDescription = itemView.findViewById(R.id.itens_recyclerviewadapter_description);
            textPrice = itemView.findViewById(R.id.itens_recyclerviewadapter_price);
            textCategory = itemView.findViewById(R.id.itens_recyclerviewadapter_category);
            icon = itemView.findViewById(R.id.itens_recyclerviewadapter_icon);
            checkBox = itemView.findViewById(R.id.itens_recyclerviewadapter_checkbox);
        }
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        viewOnCreate = LayoutInflater.from(context).inflate(R.layout.itens_recyclerviewadapter, parent, false);
        viewHolderLocal = new ViewHolder(viewOnCreate);
        return viewHolderLocal;
    }

    @Override
    public void onBindViewHolder(final RecyclerViewAdapter.ViewHolder holder, final int position) {
        holder.textDescription.setText(productsDescription.get(position));

        Log.d("image", " 3 " + images[position]);


        DecimalFormat formatMoney = new DecimalFormat("'US$' #.##");
        holder.textPrice.setText("Price: " + formatMoney.format(new BigDecimal(prices[position])));

        holder.textCategory.setText("Category: " + category[position]);

        if(images[position].equals("") || images[position].equals("null")){

            holder.icon.setImageResource(R.mipmap.ic_without_image);

        } else {
            byte[] imageInBytes;
            imageInBytes = Base64.decode(images[position], Base64.DEFAULT);
            Bitmap imageDecoded = BitmapFactory.decodeByteArray(imageInBytes, 0, imageInBytes.length);
            holder.icon.setImageBitmap(imageDecoded);
        }



        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if(productsToRemove.contains(id[position])){
                    productsToRemove.remove(id[position]);
                } else {
                    productsToRemove.add(id[position]);
                }




            }
        });


        viewOnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                productsToRemove = new ArrayList<>();
                Intent intent = new Intent(context, AddProduct.class);
                intent.putExtra("editing", "y");
                intent.putExtra("id", String.valueOf(id[position]));
                intent.putExtra("description", productsDescription.get(position));
                intent.putExtra("category", category[position]);
                intent.putExtra("price", prices[position]);
                intent.putExtra("image", images[position]);
                Log.d("image", " 2 " + images[position]);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                v.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return productsDescription.size();
    }

}

