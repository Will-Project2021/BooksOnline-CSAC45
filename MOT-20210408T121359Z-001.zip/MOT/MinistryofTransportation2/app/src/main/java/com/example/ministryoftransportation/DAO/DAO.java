package com.example.ministryoftransportation.DAO;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.ministryoftransportation.OBJECTS.Product;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class DAO extends SQLiteOpenHelper {
    public DAO(Context context) {
        super(context, "mot", null, 11);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql_product = "CREATE TABLE product (" +
                "productId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "productDescription TEXT, " +
                "productPrice REAL, " +
                "productCategory TEXT, " +
                "productImage TEXT);";
        db.execSQL(sql_product);

        ContentValues data = new ContentValues();

        data.put("productDescription", "Advanced driver training handbook");
        data.put("productPrice", String.valueOf(new BigDecimal(13.95)));
        data.put("productCategory", "Store");
        db.insert("product", null, data );

        data.put("productDescription", "Detran GO mobile game");
        data.put("productPrice", String.valueOf(new BigDecimal(49.95)));
        data.put("productCategory", "Store");
        db.insert("product", null, data );

        data.put("productDescription", "Additional road testing");
        data.put("productPrice", String.valueOf(new BigDecimal(99)));
        data.put("productCategory", "Store");
        db.insert("product", null, data );

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if(!db.isReadOnly()){
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql_drop_product = "DROP TABLE IF EXISTS product";

        db.execSQL(sql_drop_product);
        onCreate(db);
    }

    public List<Product> findProduct(String editing) {

        String sql = "SELECT * FROM product;";
        SQLiteDatabase db = getReadableDatabase();

        List<Product> productList = new ArrayList<Product>();
        Cursor c = db.rawQuery(sql, null);

        while(c.moveToNext()) {
            Product product = new Product();
            product.setId(Integer.valueOf(c.getString(c.getColumnIndex("productId"))));
            product.setDescription(c.getString(c.getColumnIndex("productDescription")));
            product.setPrice(c.getString(c.getColumnIndex("productPrice")));
            product.setCategory(c.getString(c.getColumnIndex("productCategory")));

            product.setImage(c.getString(c.getColumnIndex("productImage")));

            Log.d("image 5", " 5 " + c.getString(c.getColumnIndex("productImage")));
            productList.add(product);
        }
        return productList;
    }

    public void insertProduct(Product product) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues data = new ContentValues();

        data.put("productId", product.getId());
        data.put("productDescription", product.getDescription());
        data.put("productPrice", product.getPrice());
        data.put("productCategory", product.getCategory());

        if(!product.getImage().equals("")){
            data.put("productImage", product.getImage());
        }




        try{
            db.insertOrThrow("product", null, data );
        } catch (SQLiteConstraintException e) {
            data.put("productId", product.getId());
            db.update("product", data, "productId = ?", new String[]{String.valueOf(product.getId())});
        }


    }

    public void removeProduct(Integer productId) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "DELETE FROM product WHERE productId = " + "'" + productId + "'";
        db.execSQL(sql);
    }


}