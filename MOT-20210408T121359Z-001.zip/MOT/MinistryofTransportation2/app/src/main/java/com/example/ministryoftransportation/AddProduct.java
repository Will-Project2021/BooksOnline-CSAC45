package com.example.ministryoftransportation;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.example.ministryoftransportation.DAO.DAO;
import com.example.ministryoftransportation.OBJECTS.Product;

import java.io.ByteArrayOutputStream;

public class AddProduct extends AppCompatActivity {

    ImageView addImage;
    String imageInString = "";
    String id;
    EditText description;
    EditText price;
    Spinner category;
    Button add;
    Button cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        ActionBar actionBar = getSupportActionBar();

        actionBar.setTitle("Adding product");

        addImage = findViewById(R.id.activity_add_product_imageview);
        description = findViewById(R.id.activity_add_product_edit_description);
        price = findViewById(R.id.activity_add_product_edit_price);
        category = findViewById(R.id.activity_add_product_spinner_category);
        add = findViewById(R.id.activity_add_product_button_add);
        cancel = findViewById(R.id.activity_add_product_button_cancel);

        Intent intent = getIntent();

        if(intent.getStringExtra("editing").equals("y")){

            add.setText("UPDATE PRODUCT");

            id = intent.getStringExtra("id");
            Log.d("id 1 ", id);

            description.setText( intent.getStringExtra("description"));

            price.setText(intent.getStringExtra("price"));

            category.setSelection(((ArrayAdapter<String>)category.getAdapter()).getPosition("category"));


            if (intent.getStringExtra("image") != null) {
                if (intent.getStringExtra("image").equals("") ||
                        intent.getStringExtra("image").equals("null")) {
                    addImage.setImageResource(android.R.drawable.ic_menu_camera);
                } else {

                    byte[] imagemEmBytes;
                    imagemEmBytes = Base64.decode(
                            intent.getStringExtra("image"),
                            Base64.DEFAULT);
                    Bitmap imagemDecodificada =
                            BitmapFactory.decodeByteArray(
                                    imagemEmBytes,
                                    0,
                                    imagemEmBytes.length);
                    addImage.setImageBitmap(
                            imagemDecodificada);
                }
            }
        }





        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder selecionaFoto = new AlertDialog.Builder(AddProduct.this);
                selecionaFoto.setTitle("Source of image");
                selecionaFoto.setMessage("Please select the source:");
                selecionaFoto.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, 1);
                    }
                });
                selecionaFoto.setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                        startActivityForResult(intent, 2);
                    }
                });
                selecionaFoto.create().show();
            }
        });








        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertProduct();
            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }


    private void insertProduct() {
        DAO dao = new DAO(getApplicationContext());
        Product product = new Product();
        product.setDescription(description.getText().toString());

        try{
            product.setId(Integer.valueOf(id));
        } catch (Exception e) {

        }


        product.setPrice(price.getText().toString());
        product.setCategory(category.getSelectedItem().toString());
        product.setImage(imageInString);
        dao.insertProduct(product);
        dao.close();
        finish();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent dados) {
        super.onActivityResult(requestCode, resultCode, dados);
        if(requestCode == 1) {
            if(resultCode == RESULT_OK){
                try{

                    Bitmap fotoRegistrada = (Bitmap) dados.getExtras().get("data");
                    Bitmap fotoRedimensionada = Bitmap.createScaledBitmap(fotoRegistrada, 256, 256, true);


                    addImage.setImageBitmap(fotoRedimensionada);
                    byte[] fotoEmBytes;
                    ByteArrayOutputStream streamDaFotoEmBytes =
                            new ByteArrayOutputStream();

                    fotoRedimensionada.compress(Bitmap.CompressFormat.PNG,
                            70,
                            streamDaFotoEmBytes);

                    fotoEmBytes = streamDaFotoEmBytes.toByteArray();

                    imageInString = Base64.encodeToString(
                            fotoEmBytes,
                            Base64.DEFAULT);

                } catch (Exception e) {

                }
            } else {
                addImage.setImageResource(android.R.drawable.ic_menu_camera);
                imageInString = "null";
            }
        } else if(requestCode == 2) {
            if(resultCode == RESULT_OK){
                try{

                    Uri imageUri = dados.getData();

                    Bitmap fotoBuscada = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                    Bitmap fotoRedimensionada = Bitmap.createScaledBitmap(fotoBuscada, 256, 256, true);

                    addImage.setImageBitmap(fotoRedimensionada);
                    byte[] fotoEmBytes;
                    ByteArrayOutputStream streamDaFotoEmBytes =
                            new ByteArrayOutputStream();

                    fotoRedimensionada.compress(Bitmap.CompressFormat.PNG,
                            70,
                            streamDaFotoEmBytes);

                    fotoEmBytes = streamDaFotoEmBytes.toByteArray();

                    imageInString = Base64.encodeToString(
                            fotoEmBytes,
                            Base64.DEFAULT);

                } catch (Exception e) {

                }
            } else {
                addImage.setImageResource(android.R.drawable.ic_menu_camera);
                imageInString = "null";
            }
        }
    }

    private void emptyForm() {
        description.setText("");
        description.requestFocus();
        price.setText("");
    }
}